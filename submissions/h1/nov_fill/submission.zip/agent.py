"""
agent.py  --  BatteryAgent h1 (hard mode: profile forecasts + uncertainty-aware exact planner)

Hard mode: battery 6,000 kWh / +-1,500 kW, solar x12, obs carries only 3 hours of price / CO2
and the last hour's load and solar. Each hour the agent

  1. forecasts the score signal  w = co2 + KAPPA * price  for the next H hours: mean by
     (month, weekend, hour) of the train set, rescaled to match the hours known from obs
     (the correction fades with the horizon); the known hours overwrite the forecast,
  2. forecasts the campus net load (load - solar, kW) for the same hours: load = mean by
     (weekend, hour) plus the last hour's anomaly (fading); solar = mean by (month, hour) times
     the last hour's clearness ratio (fading),
  3. turns the first SCEN_HOURS hours of that forecast into Q equally likely scenarios by adding
     the errors this forecaster made on the train set (by hour of day and horizon),
  4. finds the command that minimises the EXPECTED  sum w_k * grid_import_k  over the H hours
     and applies it. Discharging more than the campus draws earns nothing, so with an uncertain
     load the plan discharges up to a quantile of it instead of a fixed haircut.

Planner (exact, no solver): the cost-to-go is convex and piecewise linear in the state of
charge, so it is described by its slope = the marginal value of a stored kWh, a decreasing step
function kept as a sorted list of (value, width in kWh) segments. One hour of the campus is such
a list too (what each extra kW of charge costs / each extra kW of discharge earns, weighted by
the probability that the campus can use it). Going back one hour = merge the two sorted lists
and cut what the inverter can move in an hour off both ends.

Calendar: the forecast hours are taken as consecutive hours. Optional (BatteryAgent.week_rule,
OFF by default: it lowered the score on 2 of 3 validation folds): the test set is the last 7
days of every month, back to back, so forecast hours past the end of the current week can use
the calendar of the first day of the next month's week instead.

Guard
-----
* Every command is clamped to the power and capacity limits read from obs (0 infractions).
* act() never raises and never returns NaN / inf: anything unusable gives 0.0 kW.
* When obs carries fewer than 3 price / CO2 values the run is ending: the plan covers only the
  hours that remain.

The fitted tables live in h1_tables.json next to this file (written by build.py).
"""
import datetime
import json
from bisect import bisect_left
from pathlib import Path

import numpy as np

ETA = 0.9 ** 0.5             # one-way efficiency
EPS = 1e-4                   # safety margin on the physical limits
CAP_DEFAULT = 6000.0         # kWh, used when obs has no "cap_max_kwh"
PMAX_DEFAULT = 1500.0        # kW, used when obs has no "power_max_kw"
LOOKAHEAD = 3                # price / CO2 values obs carries in hard mode
DATA_NAME = "h1_tables.json"
INF = float("inf")
NAN = float("nan")
BIG_KW = 1e7                 # forecasts are clipped to +-BIG_KW before planning
_DIM = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)


# ------------------------------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------------------------------
def _num(x):
    """float(x) if x is a finite number, else NaN. Never raises."""
    try:
        x = float(x)
    except Exception:
        return NAN
    return x if abs(x) < INF else NAN


def _vec(x):
    """1-D float array from a list-like (NaN where a value is not a number). Never raises."""
    try:
        return np.atleast_1d(np.asarray(x, float)).ravel()
    except Exception:
        pass
    try:
        return np.array([_num(v) for v in x], float)
    except Exception:
        return np.zeros(0)


def _calendar(ts):
    """(year, month, day, day of week [Mon=0], hour) from any timestamp-like value (pandas,
    datetime, numpy, 'YYYY-MM-DD HH:MM:SS' text), or None."""
    try:
        s = str(ts)
        y, m, d, h = int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13])
        if s[4] != "-" or s[7] != "-" or not 0 <= h <= 23:
            return None
        return y, m, d, datetime.date(y, m, d).weekday(), h
    except Exception:
        return None


def _week_days(y, m, rule):
    """(first, last) day of month `m` that belongs to the evaluated week.
    rule = "last7": the last 7 days of the month (the test set);  (lo, hi): fixed days."""
    if rule == "last7":
        leap = (y % 4 == 0 and y % 100 != 0) or y % 400 == 0
        dim = 29 if (m == 2 and leap) else _DIM[m - 1]
        return dim - 6, dim
    return int(rule[0]), int(rule[1])


def horizon_calendar(y, m, d, dow, hour, H, rule=None, parts="both"):
    """Calendar of the next H rows of the run, row 0 = (m, dow, hour):
    (month index 0..11 or 12 = unknown, weekend flag 0/1, hour of day), each of length H.
    rule = None: consecutive hours, the month of row 0 throughout.
    Otherwise the rows after the last hour of this month's week are the first hours of the
    next month's week (see _week_days); parts = "both", or "dow" / "month" to take only the
    weekdays / only the month from the next week."""
    step = hour + np.arange(H)
    hh = step % 24
    dw = (dow + step // 24) % 7
    mi = np.full(H, 12 if m is None else m - 1)
    if rule is not None and m is not None and y is not None and d is not None:
        try:
            lo, hi = _week_days(y, m, rule)
            left = (hi - d) * 24 + (24 - hour)               # rows left in this week, this one included
            if lo <= d <= hi and 0 < left < H:
                y2, m2 = (y + 1, 1) if m == 12 else (y, m + 1)
                lo2 = _week_days(y2, m2, rule)[0]
                dow2 = datetime.date(y2, m2, lo2).weekday()
                j = np.arange(H - left)
                hh[left:] = j % 24
                if parts != "month":
                    dw[left:] = (dow2 + j // 24) % 7
                if parts != "dow":
                    mi[left:] = m2 - 1
        except Exception:
            pass
    return mi, (dw >= 5).astype(int), hh


# ------------------------------------------------------------------------------------------
# Forecasts (pure functions of the tables; build.py replays net_forecast to fit the scenarios)
# ------------------------------------------------------------------------------------------
def net_forecast(load_tab, pv_tab, phi, phi_pv, mi, we, hh, lwe, lh, load_last, pv_last):
    """Point forecast of the net load (kW) of the next len(hh) rows.
    load_tab [weekend, hour], pv_tab [month index, hour]; (mi, we, hh) from horizon_calendar;
    lwe, lh: weekend flag and hour of the hour the readings load_last / pv_last belong to."""
    j = np.arange(1, len(hh) + 1)
    anom = load_last - load_tab[lwe, lh]
    if anom != anom:
        anom = 0.0                                           # no reading: plain profile
    load = np.maximum(load_tab[we, hh] + anom * phi ** j, 0.0)
    ratio = 1.0
    ref = pv_tab[mi[0], lh]
    if ref > 20.0 and pv_last == pv_last:
        ratio = min(max(pv_last / ref, 0.0), 3.0)
    return load - pv_tab[mi, hh] * (1.0 + (ratio - 1.0) * phi_pv ** j)


def signal_forecast(w_tab, half, mi, we, hh, known):
    """Score signal of the next len(hh) rows. w_tab [month index, weekend, hour];
    known: the values obs gives for the first rows (NaN where unusable)."""
    H = len(hh)
    clim = w_tab[mi, we, hh]
    k = min(len(known), H)
    known = known[:k]
    ok = np.isfinite(known)
    w = clim
    if ok.any():
        ratio = float(np.mean(known[ok])) / max(float(np.mean(clim[:k][ok])), 1e-9)
        ratio = min(max(ratio, 0.2), 5.0)
        w = clim * (1.0 + (ratio - 1.0) * 0.5 ** (np.arange(H) / half))
    w = np.array(w, float)
    w[:k][ok] = known[ok]
    return w


# ------------------------------------------------------------------------------------------
# Planner: exact dynamic programme on the marginal value of stored energy
# ------------------------------------------------------------------------------------------
def stage_segments(w, n_scen, probs, pmax, eta):
    """Marginal value / cost of battery power in each hour, per kWh of SOC.
    w (K,), n_scen (K, Q), probs (Q,) -> (val, wid), both (K, Q + 2): the segments of each hour
    ordered from full charge (+pmax) to full discharge (-pmax); val is non-increasing along
    that order, wid is the SOC width (kWh) of each segment."""
    K, Q = n_scen.shape
    y = np.empty((K, Q + 3))
    y[:, 0] = -pmax
    y[:, 1] = 0.0
    y[:, 2] = pmax
    np.clip(n_scen, -pmax, pmax, out=y[:, 3:])
    y.sort(axis=1)
    mid = 0.5 * (y[:, 1:] + y[:, :-1])
    surv = ((n_scen[:, None, :] > mid[:, :, None]) * probs).sum(axis=2)      # P(n > mid)
    neg = mid < 0.0
    wid = (y[:, 1:] - y[:, :-1]) * np.where(neg, eta, 1.0 / eta)
    val = w[:, None] * surv * np.where(neg, 1.0 / eta, eta)
    return val, wid


def stage_segments_det(w, n, pmax, eta):
    """Same for one scenario per hour (3 segments per hour)."""
    y = np.clip(n, -pmax, pmax)
    val = np.zeros((len(w), 3))
    wid = np.empty((len(w), 3))
    pos = y > 0.0
    ym = np.minimum(y, 0.0)
    wid[:, 0] = (ym + pmax) * eta                    # charging from the grid: paid at w / eta
    val[:, 0] = w / eta
    wid[:, 1] = np.where(pos, y / eta, -ym * eta)    # useful discharge (y > 0) or free solar surplus (y < 0)
    val[:, 1] = np.where(pos, w * eta, 0.0)
    wid[:, 2] = (pmax - np.maximum(y, 0.0)) / eta    # discharge beyond the load: worth nothing
    return val, wid


def backward(sv, sw, cap, pmax, eta):
    """Backward pass over hours len-1 .. 1 (energy left after the last hour is worth nothing).
    sv, sw: per-hour lists of segment values / widths. Returns (vv, vl): marginal value of
    stored energy right after hour 0 as segments over [0, cap], vv descending."""
    vals = [0.0]                                      # ascending values = from SOC cap down to 0
    wids = [cap]
    top = pmax * eta                                  # most SOC we can add in one hour
    bot = pmax / eta                                  # most SOC we can take out in one hour
    for k in range(len(sv) - 1, 0, -1):
        for m, ln in zip(sv[k], sw[k]):               # merge this hour's segments into the sorted list
            if ln > 1e-9:
                i = bisect_left(vals, m)
                vals.insert(i, m)
                wids.insert(i, ln)
        r = top                                       # cut `top` kWh off the high-value end
        while wids:
            ln = wids[-1]
            if ln <= r:
                r -= ln
                wids.pop()
                vals.pop()
            else:
                wids[-1] = ln - r
                break
        r = bot                                       # cut `bot` kWh off the low-value end
        i = 0
        nw = len(wids)
        while i < nw:
            ln = wids[i]
            if ln <= r:
                r -= ln
                i += 1
            else:
                wids[i] = ln - r
                break
        if i:
            del vals[:i]
            del wids[:i]
    return np.array(vals[::-1]), np.array(wids[::-1])


def first_step(soc, sv, sl, vv, vl, cap, pmax, eta):
    """Optimal command (kW, + charge) for this hour. sv, sl: this hour's segments; vv, vl:
    marginal value after this hour. Ties go to the highest SOC: never spill, take free solar."""
    xlo = max(-pmax * eta, soc - cap)                 # x = SOC taken out of the battery (kWh)
    xhi = min(pmax / eta, soc)
    if xhi <= xlo:
        return 0.0
    bx = np.cumsum(sl) - pmax * eta                   # right end of each stage segment, in x
    bs = np.cumsum(vl)                                # right end of each value segment, in SOC
    cand = np.concatenate((bx, soc - bs, (xlo, xhi)))
    np.clip(cand, xlo, xhi, out=cand)
    cand.sort()
    mid = 0.5 * (cand[1:] + cand[:-1])
    i0 = np.minimum(np.searchsorted(bx, mid, side="right"), len(sv) - 1)
    i1 = np.minimum(np.searchsorted(bs, soc - mid, side="right"), len(vv) - 1)
    g = sv[i0] - vv[i1]                               # gain of taking one more kWh out; non-increasing in x
    tol = 1e-12 * (1.0 + sv[0])
    nz = np.flatnonzero(g > tol)
    x = cand[nz[-1] + 1] if len(nz) else xlo
    return float(-x * eta if x > 0 else -x / eta)


def plan(w, n_scen, probs, n_tail, soc, cap, pmax, eta=ETA):
    """First command (kW, + charge) of the plan that minimises the expected import cost.
    w (H,); n_scen (K, Q), K >= 1: scenarios of the first K hours; n_tail (H - K,): point
    forecast of the rest. All inputs must be finite."""
    K = len(n_scen)
    sv0, sl0 = stage_segments(w[:K], n_scen, probs, pmax, eta)
    sv, sl = sv0.tolist(), sl0.tolist()
    if len(n_tail):
        tv, tl = stage_segments_det(w[K:K + len(n_tail)], n_tail, pmax, eta)
        sv += tv.tolist()
        sl += tl.tolist()
    vv, vl = backward(sv, sl, cap, pmax, eta)
    return first_step(soc, sv0[0], sl0[0], vv, vl, cap, pmax, eta)


# ------------------------------------------------------------------------------------------
# Agent
# ------------------------------------------------------------------------------------------
def _default_path():
    try:
        return Path(__file__).parent / DATA_NAME
    except Exception:
        return Path(DATA_NAME)


class BatteryAgent:
    data_path = None         # set on the class before construction to load other tables (validation)
    horizon = None           # planning horizon in hours; None = the value stored in the tables
    end_of_run = True        # plan only over the remaining hours when obs carries < 3 values
    week_rule = None         # rows of the run: None = consecutive hours (default), "last7" = last 7 days
    #                          of every month (the test set), (lo, hi) = those days of every month
    week_parts = "both"      # what the week rule changes past the boundary: "both", "dow" or "month"
    d_shade = 1.0            # extra haircut on this hour's positive net-load scenarios (1.0 = none)

    def __init__(self):
        self.ready = False
        self.month = None                # last month seen (used if a timestamp cannot be read)
        try:
            self._load(self.data_path if self.data_path is not None else _default_path())
            self.ready = True
        except Exception:
            self.ready = False

    def _load(self, path):
        with open(str(path), "r", encoding="utf-8") as f:
            t = json.load(f)
        self.kappa = float(t["kappa"])               # weight of price relative to CO2 in the signal
        self.half = float(t["half"])                 # half-life (h) of the signal's level correction
        self.phi = float(t["phi"])                   # hourly decay of the load anomaly
        self.phi_pv = float(t["phi_pv"])             # hourly decay of the solar clearness correction
        self.H = int(self.horizon if self.horizon is not None else t["H"])
        self.scen_hours = int(t["scen_hours"])       # leading hours planned against scenarios
        w_tab = np.asarray(t["w_tab"], float)                # [month-1, weekend, hour]
        w_any = np.asarray(t["w_any"], float)                # [weekend, hour]        (month unknown)
        self.load_tab = np.asarray(t["load_tab"], float)     # [weekend, hour]
        pv_tab = np.asarray(t["pv_tab"], float)              # [month-1, hour]
        pv_any = np.asarray(t["pv_any"], float)              # [hour]                 (month unknown)
        self.off = np.asarray(t["offsets"], float)           # [hour of day, horizon, scenario]  (kW)
        self.probs = np.asarray(t["probs"], float)           # [scenario]
        if (w_tab.shape != (12, 2, 24) or w_any.shape != (2, 24) or self.load_tab.shape != (2, 24)
                or pv_tab.shape != (12, 24) or pv_any.shape != (24,) or self.off.ndim != 3
                or self.off.shape[0] != 24 or self.off.shape[2] != len(self.probs)
                or self.H < 1 or self.scen_hours < 1):
            raise ValueError("bad tables")
        self.w_tab = np.concatenate([w_tab, w_any[None]])    # month index 12 = unknown month
        self.pv_tab = np.concatenate([pv_tab, pv_any[None]])
        for a in (self.w_tab, self.load_tab, self.pv_tab, self.off, self.probs):
            if not np.isfinite(a).all():
                raise ValueError("bad tables")
        if not (self.probs > 0).all() or abs(float(self.probs.sum()) - 1.0) > 1e-6:
            raise ValueError("bad tables")

    # -- calendar ----------------------------------------------------------------------------
    def _when(self, obs):
        """(year, month, day, day of week, hour) of the hour being decided; None where unknown."""
        cal = _calendar(obs.get("timestamp"))
        if cal is not None:
            self.month = cal[1]
            return cal
        h = _num(obs.get("hour"))
        d = _num(obs.get("day_of_week"))
        hour = int(h) if (h == h and 0 <= h <= 23) else 12
        dow = int(d) if (d == d and 0 <= d <= 6) else 2
        return None, self.month, None, dow, hour

    # -- plan --------------------------------------------------------------------------------
    def _decide(self, obs, soc, cap, pmax):
        y, m, d, dow, hour = self._when(obs)

        # ---- known part of the signal ----
        co2 = _vec(obs.get("co2_properes_24h"))
        price = _vec(obs.get("preus_properes_24h"))
        nk = min(len(co2), len(price))
        known = co2[:nk] + self.kappa * price[:nk]
        w0 = _num(obs.get("co2_actual")) + self.kappa * _num(obs.get("preu_actual"))
        H = self.H
        if nk == 0:
            known = np.array([w0])                   # lists missing: fall back on the scalar fields
        else:
            if known[0] != known[0]:
                known[0] = w0
            if self.end_of_run and nk < LOOKAHEAD:
                H = min(H, nk)                       # the run ends in nk hours: nothing to save for later

        # ---- forecasts ----
        mi, we, hh = horizon_calendar(y, m, d, dow, hour, H, self.week_rule, self.week_parts)
        w = signal_forecast(self.w_tab, self.half, mi, we, hh, known)
        w = np.minimum(np.maximum(np.where(np.isfinite(w), w, 1e-9), 1e-9), 1e9)
        try:
            last = obs.get("noves_dades_5min")
            load_last, pv_last = _num(last.get("ultim_consum_kw")), _num(last.get("ultima_solar_kw"))
        except Exception:
            load_last = pv_last = NAN
        lh = (hour - 1) % 24
        lwe = int((dow if hour > 0 else (dow - 1) % 7) >= 5)
        n = net_forecast(self.load_tab, self.pv_tab, self.phi, self.phi_pv, mi, we, hh, lwe, lh, load_last, pv_last)
        n = np.clip(np.where(np.isfinite(n), n, 0.0), -BIG_KW, BIG_KW)

        # ---- scenarios for the first hours, point forecast for the rest ----
        K = min(self.scen_hours, H)
        kk = np.minimum(np.arange(K), self.off.shape[1] - 1)
        scen = n[:K, None] + self.off[hh[:K], kk]
        if self.d_shade != 1.0:
            scen[0] = np.where(scen[0] > 0, scen[0] * self.d_shade, scen[0])
        return plan(w, scen, self.probs, n[K:], min(max(soc, 0.0), cap), cap, pmax)

    # -- API ---------------------------------------------------------------------------------
    def act(self, obs: dict) -> float:
        try:
            cap = _num(obs.get("cap_max_kwh", CAP_DEFAULT))
            pmax = _num(obs.get("power_max_kw", PMAX_DEFAULT))
            if not cap > 0.0:
                cap = CAP_DEFAULT
            if not pmax > 0.0:
                pmax = PMAX_DEFAULT
            soc = _num(obs.get("soc_kwh"))
            if soc != soc:                           # fall back on the relative fields
                soc = _num(obs.get("soc_pct")) * cap
            if soc != soc:
                soc = _num(obs.get("soc_percent")) * cap / 100.0
        except Exception:
            return 0.0
        if soc != soc:
            return 0.0                               # state unknown: 0 kW is the only command that is always legal
        p = 0.0
        if self.ready:
            try:
                p = float(self._decide(obs, soc, cap, pmax))
            except Exception:
                p = 0.0
        if p != p or abs(p) == INF:
            p = 0.0
        max_c = max(0.0, min(pmax, (cap - soc) / ETA - EPS))
        max_d = max(0.0, min(pmax, soc * ETA - EPS))
        return float(min(max(p, -max_d), max_c)) + 0.0           # + 0.0: never -0.0
